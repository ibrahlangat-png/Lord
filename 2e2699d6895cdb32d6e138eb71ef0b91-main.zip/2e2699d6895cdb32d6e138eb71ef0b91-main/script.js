function sendTelegram() {
  const message = document.getElementById("msgInput").value;
  const status = document.getElementById("statusMsg");

  if (!message) {
    status.innerText = "Please type something first!";
    status.style.color = "orange";
    return;
  }

  const botToken = "8001472091:AAES8rZsnC3zOmbPYe7cVpnf6dafZDkFfbY";
  const chatId = "8014905607";
  const url = `https://api.telegram.org/bot${botToken}/sendMessage`;

  fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      chat_id: chatId,
      text: message
    })
  })
    .then(response => response.json())
    .then(data => {
      if (data.ok) {
        status.innerText = "Message sent successfully ✅";
        status.style.color = "lime";
        document.getElementById("msgInput").value = "";
      } else {
        status.innerText = "Failed to send ❌";
        status.style.color = "red";
      }
    })
    .catch(err => {
      status.innerText = "Error sending message ⚠️";
      status.style.color = "red";
    });
}
